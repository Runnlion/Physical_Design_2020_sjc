#pragma once
#define CHANGE_SIZE 20
int main(int argc, char* argv[]);
