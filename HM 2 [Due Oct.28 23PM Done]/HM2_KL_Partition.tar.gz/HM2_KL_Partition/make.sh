g++ ./Source/KL_Partition.cpp -o ./KL_Partition -std=c++11 -Wall -Wextra
g++ ./Source/KL_Partition_Optimized.cpp -o ./KL_Partition_Optimized -std=c++11 -Wall -Wextra
